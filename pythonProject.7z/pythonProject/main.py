import json
import sqlite3
import flask


def run_sql(sql):
    with sqlite3.connect("netflix.db") as connection:
        connection.row_factory = sqlite3.Row
        return connection.execute(sql).fetchall()


app = flask.Flask(__name__)

@app.get("/movie/<title>")
def step_1(title):

    sql = f"""
            SELECT title, country, release_year, listed_in AS genre, description, date_added FROM netflix
            WHERE title='{title}' 
            ORDER BY date_added DESC
        """

    result = None
    for item in run_sql(sql):
        result = dict(item)
    return flask.jsonify(result)

    # result = run_sql(sql)
    # return result


@app.get("/movie/<int:year1>/to/<int:year2>")
def step_2(year1, year2):
    sql = f"""
            SELECT title, release_year FROM netflix
            WHERE release_year BETWEEN {year1} AND {year2}
            ORDER BY release_year
        """
    return flask.jsonify(run_sql(sql))

@app.get("/rating/<rating>")
def step_3(rating):
    my_dict = {
        "children": ("G", "G"),
        "family": ("G", "PG", "PG-13"),
        "adult": ("R", "NC-17")
    }

    sql = f"""
        SELECT title, rating, description FROM netflix
        WHERE rating IN {my_dict.get(rating, ('PG-13', 'NC-17'))}
    """

    return flask.jsonify(run_sql(sql))


@app.get("/genre/<genre>")
def step_4(genre):
    sql = f"""
        SELECT * FROM netflix
        WHERE listed_in LIKE '%{genre.title()}%'
    """

    return flask.jsonify(run_sql(sql))


def step_5(name1='Rose McIver', name2='Ben Lanb'):
    sql = f"""
        SELECT "cast" FROM netlix
        WHERE "cast" LIKE '%{name1}%' AND "cast" LIKE '%{name2}%'
    """

    result = run_sql(sql)
    main_name = {}

    for item in result:
        names = item.get('cast').split(", ")
        for name in names:
           main_name[name] = main_name.get(name, 0) + 1


    result = []
    main_name.__delitem__(name1)
    main_name.__delitem__(name2)
    for item in main_name:
        if main_name[item] >= 2:
            result.append(item)

    return result

def step_6(types='TV Show', release_year=2021, genre='TV'):
    sql = f"""
        SELECT * FROM netflix
        WHERE type = '{types}'
        AND release_year = '{release_year}'
        AND listed_in LIKE '%{genre}%'
    """

    return  json.dumps(run_sql(sql), indent=4, ensure_ascii=False)

if __name__ = "__main__":
    app.run(debug=True)
    
    # print(step_1(title='Hilda'))

